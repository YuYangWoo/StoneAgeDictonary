package com.cookandroid.stoneagedc;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class setPetActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setpet);
        setTitle("펫 육성법");

    }
}
